package gameelements.client;

import main.Stoppable;
import gameelements.GameElement;

public interface ClientGameElement extends Runnable, Stoppable, GameElement {
	public int getLife();
}
