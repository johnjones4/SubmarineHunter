package gameelements;


public interface DestructiveGameElement extends GameElement {
    public int getYield();
}
