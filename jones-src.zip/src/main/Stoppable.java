package main;

public interface Stoppable {
	public void stop();
	public boolean isStopped();
	public void launch();
}
