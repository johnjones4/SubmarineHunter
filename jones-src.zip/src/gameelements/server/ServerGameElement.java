package gameelements.server;
import gameelements.GameElement;
import server.GameElementUpdate;

public interface ServerGameElement extends GameElement {
	public void update(GameElementUpdate update);
	public void reset(GameElementUpdate update);
}
